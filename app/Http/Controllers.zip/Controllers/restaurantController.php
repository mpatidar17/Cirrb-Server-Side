<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Models\Branch;
use App\Models\Restaurant;
use App\Models\Menu;
use View;
use Input;
use Validator;
use Redirect;

class restaurantController extends Controller
{
  public function __construct(){

      $this->middleware('auth');

    }

  public function index(){

    $restaurants = Restaurant::all();

    return View::make('adminpanel.restaurant')->with('restaurants',$restaurants);

  }
  public function store(){

    $restaurant = new Restaurant;

    $restaurant->approved = Input::get('approval');
    $restaurant->name = Input::get('name');
    $restaurant->description = Input::get('description');
    $restaurant->phone = Input::get('phone');
    $restaurant->email = Input::get('email');
    $restaurant->image = 'http://localhost:8000/images/restaurent-1.png';
    $restaurant->approved_on = date('Y-m-d h:i:s');
    $restaurant->save();

    //return Session::falsh('message',"Restaurant Created Successfully");
    
    return "Restaurant Created Successfully";

  }
  public function show( $id ){

    $restaurant = Restaurant::find( $id );

    $branches = Restaurant::find( $id )->branches;

    $menus = Restaurant::find( $id )->menus;

    return View::make('adminpanel.detail')
    ->with('restaurant',$restaurant)
    ->with('branches',$branches)
    ->with('menus',$menus);

  }
  public function update( $restaurant_id ){

    $restaurant = Restaurant::find( $restaurant_id );

    $data = array(
      'name' => Input::get('name'),
      'email' => Input::get('email'),
      'phone' => Input::get('phone'),
      'description' => Input::get('description'),
    );


      $restaurant->name = $data['name'];
      $restaurant->email = $data['email'];
      $restaurant->description = $data['description'];
      $restaurant->phone = $data['phone'];
      $restaurant->save();

      return json_encode(array('status' => 'success','details' => $data ));

  }
      
}