<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use View;
use App\Models\Menu;
use Input;
use Redirect;

class menuController extends Controller
{
    public function store(){

      $menu = new Menu;

      $data = array(
        'restaurant_id' => Input::get('restaurant_id'),
        'name' => Input::get('name'),
        'description' => Input::get('description'),
        'price' => Input::get('price'),
        );

      $menu->restaurant_id = $data['restaurant_id'];      
      $menu->branch_id = 0; 
      $menu->name = $data['name'];
      $menu->description = $data['description'];
      $menu->price = $data['price'];
      $menu->image = "http://localhost:8000/images/restaurent-1.png";
      $menu->save();

      return json_encode(['status' => 'success','details' => $data]);

    }
    public function edit( $restaurant_id ){

      $menu = new Menu;

      $data = array(
        'restaurant_id' => Input::get('restaurant_id'),
        'name' => Input::get('name'),
        'description' => Input::get('description'),
        'price' => Input::get('price'),
        );

      $menu->restaurant_id = $data['restaurant_id'];      
      $menu->branch_id = 0; 
      $menu->name = $data['name'];
      $menu->description = $data['description'];
      $menu->price = $data['price'];
      $menu->image = "http://localhost:8000/images/restaurent-1.png";
      $menu->save();

      return json_encode(['status' => 'success','details' => $data]);

    }
}
