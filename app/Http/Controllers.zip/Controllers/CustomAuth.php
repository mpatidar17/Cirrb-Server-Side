<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use Input;
use Validator;
use Mail;
use DB;

class CustomAuth extends Controller
{
    public function register(){

      $data = array(
        'name' => Input::get('name'),
        'last_name' => Input::get('last_name'),
        'email' => Input::get('email'),
        'password' => Input::get('password'),
        'password_confirmation' => Input::get('password_confirmation'),
        'device_token' => Input::get('device_token'),
        'device_type' => Input::get('device_type'),
        );

      $validator = Validator::make($data, [
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
            'device_token' => 'required',
            'device_type' => 'required',
        ]);

      if( $validator->fails() ){

        return $validator->errors();

      }else{

        User::create([
            'display' => $data['name']." ".$data['last_name'],
            'name' => $data['name'],
            'last_name' => $data['last_name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'device_token' => $data['device_token'],
            'device_type' => $data['device_type'],
            'auth_token' => NULL,
            'lat' => 0,
            'long' => 0,
        ]);

        return array("status" => "success","message" => "Registred Successfully");

      }

    }

  public function login(){

    $email = Input::get("email");
    
    $password = Input::get("password");

    $device_type = Input::get("device_type");

    $device_token = Input::get("device_token");

    $remember = Input::get("remember");

    if( Auth::attempt([ "email" => $email,"password" => $password ],$remember) ){

      $user = User::where('email', '=', $email)->first();

      $user->auth_token = md5(uniqid(rand(), true));

      $user->device_type = $device_type;

      $user->lat = 0;

      $user->long = 0;

      $user->device_token = $device_token;

      $user->save();

      return User::where('email', '=', $email)->first();

    }else{

      return array("status"=>"fail","message" => "Invalid Credentials");

    }

  }
  
  public function forgotPassword(){

    $email = Input::get("email");

    $user = User::where('email', '=', $email)->first();

    if( count($user) > 0 ){

      $data['code'] = mt_rand(1000, 9999);

      Mail::send('emails.resetPassword', $data, function($message) {
         $message->to(Input::get("email"),'')->subject
            ('Reset Password Code');
         $message->from('xyz@gmail.com','Dummy');
      });

      DB::insert('insert into password_resets (email, token) values (?, ?)', [$email, $data['code']]);

      return array("Status" => "success","message" => "Password reset code sent to your mail successfully");

    }
    else{

      return array("status" => "fail","message" => "No User Found");

    }

  }

  public function resetPassword(){

    $data = array(
      'token' => Input::get('code'),
      'email' => Input::get('email'),
      'password' => Input::get('password'),
      'password_confirmation' => Input::get('password_confirmation'),
      );

    $validator = Validator::make($data,[

      'token' => 'required|string',
      'email' => 'required|email|string|max:255',
      'password' => 'required|confirmed|min:6',

      ]);

    if( $validator->fails() ){

      return $validator->errors();

    }else{

      $user = User::where('email', '=', $data['email'])->first();

      $token = DB::table('password_resets')
      ->select('token')
      ->where('token',$data['token'])
      ->get();

      if( count($user) == 0 ){

        return array('status' => 'fail', 'message' => 'No User Found');
        
      }elseif( count($token) == 0  ){

        return array('status' => 'fail', 'message' => 'Invalid Code');

      }
      else{

        $user->password = bcrypt($data['password']);

        $user->save();

        DB::delete("delete from password_resets where token = ?",[$data['token']]);

        return array("status" => "success","message" => "Password Reseted Successfully");
      }

    }

  }
}
