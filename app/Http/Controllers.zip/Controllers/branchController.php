<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use View;
use App\Models\Branch;
use Input;
use Redirect;

class branchController extends Controller
{
    public function show( $restaurant_id ){

      return View::make("adminpanel.createBranch")->with('restaurant_id',$restaurant_id);

    }

    public function store(){

      $branch = new Branch;

      $branch->restaurant_id = Input::get('restaurant_id');
      $branch->name = Input::get('name');
      $branch->bl_lat = Input::get('bl_lat');
      $branch->bl_long = Input::get('bl_long');
      $branch->save();

      return Redirect::to('/restaurant-detail/'.Input::get('restaurant_id'));

    }
}
