<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Models\Branch;
use App\Models\Restaurant;
use App\Models\Menu;

class apiRestaurantController extends Controller
{
    public function getRestaurants( Request $request ){

    $auth_token = $request->header('Authorization');

    $loggedin = User::where('auth_token','=',$auth_token)->get();

    if( count($loggedin) == 0 ){

      return array('status' => 'fail', 'message' => 'Invalid Token');
    
    }

    $branches = Branch::all();

    $list = array('main' => NULL);

    foreach($branches as $branch){

       $lat1 = $request->lat;
       $lon1 = $request->long;
       $user_dist = $request->distance;

       $lat2 = $branch->bl_lat;
       $lon2 = $branch->bl_long;

       $unit = "K";

       $theta = $lon1 - $lon2;
      $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
      $dist = acos($dist);
      $dist = rad2deg($dist);
      $miles = $dist * 60 * 1.1515;
      $unit = strtoupper($unit);

       $distance = ($miles * 1.609344);

        //$user_dist = ($user_dist * 1000);

       if( $distance <= $user_dist ){

        $restaurant = Restaurant::find($branch->restaurant_id);

        // $list['branch_list'][] = $branch;

        $branch['distance'] = round($distance);



        $list['main'][] = array( 'restaurant' => $restaurant, 'branch' => $branch );
        
        //$list['restaurant_list'][] = $restaurant;


       }
    }

    $list['response'] = [ 'status' => 'success', 'details' => $list['main'] ];  

    return $list['response'];

  }
  public function getMenus( Request $request ){

    $auth_token = $request->header('Authorization');

    $loggedin = User::where('auth_token','=',$auth_token)->get();

    if( count($loggedin) == 0 ){

      return array('status' => 'fail', 'message' => 'Invalid Token');
    
    }

    $restaurant_id = $request->restaurant_id;

    $menus = Restaurant::find( $restaurant_id )->menus;

    foreach ($menus as $key => $menu) {
      $menu['quantity'] = 0;
    }

    $menu_list = array('status' => 'success','details' => $menus );

    return $menu_list;
  }
}
