<h1> Reset Password </h1>
<strong>Secret Code :</strong><br>
{{ $code }}
