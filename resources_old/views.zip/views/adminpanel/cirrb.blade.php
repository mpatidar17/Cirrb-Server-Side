<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

  <link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDYItbXAUI-TUfpigEf0cdz3TBbbCDW2Qo&callback=initMap">
  </script>
  <link rel="stylesheet" type="text/css" href="http://api.cirrb.com/_views/_media/css/style.css" />

<script type="text/javascript">
$(document).ready(function(){
    // $("#menu-toggle").click(function(e) {
    //     e.preventDefault();
    //     $("#wrapper").toggleClass("active");
    // });

    // /*Scroll Spy*/
    // $('body').scrollspy({ target: '#spy', offset:80});

    // /*Smooth link animation*/
    // $('a[href*=#]:not([href=#])').click(function() {
    //     if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

    //         var target = $(this.hash);
    //         target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
    //         if (target.length) {
    //             $('html,body').animate({
    //                 scrollTop: target.offset().top
    //             }, 1000);
    //             return false;
    //         }
    //     }
    // });
    $('#show-add-restaurant').click(function(e){
      $('#add-restaurant-form').toggle();
    });
    //  $('#cancel-add-restaurant').click(function(e){
    //   $('#add-restaurant-form').toggle();
    // });
     $("#edit-restaurant-btn").click(function(e){

        $(".field-show").toggle();
        $(".field-hide").toggle();

     });

    $("#add-restaurant").submit(function(e){
      $.ajax({

        url:'{{ URL::to("/restaurants") }}',
        type: 'post',
        data:$(this).serialize(),
        success:function(response){

          alert(response);

        }

      });
      e.preventDefault();
    });

    // $(".add-restaurant.save-btn").click(() => {})
    $(document).on('submit',"form#edit-restaurant",function(e){
          $.ajax({

            url:'{{ URL::to("/restaurants") }}/'+$("#restaurant_id").val(),
            type: 'put',
            data:$(this).serialize(),
            success:function(responseRAW){
              response = JSON.parse(responseRAW);
              $(".page-title").html(response.details.name);
              $(".restaurant-description").html(response.details.description);
              $(".restaurant-email").html(response.details.email);
              $(".restaurant-phone").html(response.details.phone);

              $(".field-show").show();
              $(".field-hide").hide();
            }
        });
        e.preventDefault();
    });

    $(document).on('click',"#add-menu",function(e){
        $("#menus-table").append('<tr id="form-table-cell"><td>{{ Form::text("name","",array("class" =>"form-control menu-name","required"=>"required")) }}</td><td>{{ Form::text("description","",array("class" =>"form-control menu-discription","required"=>"required")) }}</td><td>{{ Form::text("price","",array("class" =>"form-control menu-price","required"=>"required")) }}</td>{{ Form::hidden("restaurant_id","",array("class"=>"restaurant-id") ) }}<td><button type="submit" id="save-menu" class="add-restaurant save-btn"><span class="fa fa-plus"></span> Save</button></td></tr>');
    });
    $(document).on('click',"#save-menu",function(e){
      var name = $(".menu-name").val();
      var description = $(".menu-discription").val();
      var price = $(".menu-price").val();
      var restaurant_id = $(".restaurant-id").val();
      //debugger
          $.ajax({
            url:'{{ URL::to("/menus") }}',
            type:'post',
            data:'_token={{csrf_token()}}&name='+name+'&description='+description+'&price='+price+'&restaurant_id='+restaurant_id,
            success:function(responseRAW){
              response = JSON.parse(responseRAW);
              $("#form-table-cell").replaceWith('<tr><td>'+response.details.name+'</td><td>'+response.details.description+'</td><td>'+response.details.price+'</td></tr>');
              
            }
        });
        e.preventDefault();
    });
});
function redirectMe(id){

  return window.location='{{ URL::to("/restaurants") }}/'+id;

}
</script>

</head>
<body>
<div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <nav id="spy">
                <ul class="sidebar-nav nav">
                    <li class="sidebar-brand logo">
                        <a href="{{ URL::to('/dashboard') }}"><img src="{{ URL::to('/images/logo-white.png') }}" /></a>
                    </li>
                    <li>
                        <a href="">
                            <span >Dashboard</span>
                        </a>
                    </li>
                    <!-- <li>
                        <a href="">
                            <span>Anchor 2</span>
                        </a>
                    </li> -->
                    <li>
                        <ul class="">                     
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle " data-toggle="dropdown">
                                    <div class="">
                                       <span class="welcome">Orders</span>
                                       <i class="fa fa-angle-down pull-right"></i>
                                    </div>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="#">
                                           
                                            <span>Orders</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ajax/page_messages.html" class="ajax-link">
                                           
                                            <span>Carts</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href=" {{ URL::to('/restaurants') }} ">
                            <span >Restaurants</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span >Partners</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span >Customers</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ URL::to('/logout') }}">
                            <span >Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- Page content -->
        <div id="page-content-wrapper">
            <div class="content-header">
                <h1 id="home">
                    <a id="menu-toggle" href="#" class="glyphicon glyphicon-align-justify btn-menu toggle">
                      
                    </a>
                    <span class="page-title">@yield('page-title')</span>
                </h1>
            </div>

            <div class="page-content inset" data-spy="scroll" data-target="#spy">

                  @yield('content')

                <div class="navbar navbar-default navbar-static-bottom">
                    <p class="navbar-text pull-left">
                        
                    </p>
                </div>
            </div>

        </div>

    </div>

<script>
//Set up some of our variables.
var map; //Will contain map object.
var marker = false; ////Has the user plotted their location marker? 
        
//Function called to initialize / create the map.
//This is called when the page has loaded.
function initMap() {
 
    //The center location of our map.
    var centerOfMap = new google.maps.LatLng(24.45172302204076, 39.601284029195085);
 
    //Map options.
    var options = {
      center: centerOfMap, //Set center.
      zoom: 10 //The zoom value.
    };
 
    //Create the map object.
    map = new google.maps.Map(document.getElementById('map'), options);
}

function addMarker(id) {
  //Listen for any clicks on the map.
    google.maps.event.addListener(map, 'click', function(event) {                
        //Get the location that the user clicked.
        var clickedLocation = event.latLng;
        //If the marker hasn't been added.
        if(marker[id] === false){
            //Create the marker.
            marker[id] = new google.maps.Marker({
                position: clickedLocation,
                map: map,
                draggable: true //make it draggable
            });
            //Listen for drag events!
            google.maps.event.addListener(marker[id], 'dragend', function(event){
                markerLocation();
            });
        } else{
            //Marker has already been added, so just change its location.
            marker[id].setPosition(clickedLocation);
        }
        //Get the marker's location.
        markerLocation();
    });
}
        
//This function will get the marker's current location and then add the lat/long
//values to our textfields so that we can save the location.
function markerLocation(id){
    //Get location.
    var currentLocation = marker[id].getPosition();
    //Add lat and lng values to a field that we can save.
    document.getElementById('bl_lat').value = currentLocation.lat(); //latitude
    document.getElementById('bl_long').value = currentLocation.lng(); //longitude
}
          
</script>

<script type="text/javascript">
  
  // Javascript request URL
  var requestURL = '//api.cirrb.com/';
  
  function logout() {
    $.ajax({
      url: requestURL + '?request=profile&operation=logout',
      dataType: 'json',
      success: function(response) {
        if (response['logout'] == 1) {
          window.location = './';
        }
      }
    });
  }
  
  
  function resizeSideMenu() {
    var documentHeight = $(document).height();
    $('#sideMenu').css( 'min-height', documentHeight );
  }
  
  $(document).ready( function() {
    resizeSideMenu();
    
  });
  $(window).resize( function() {
    resizeSideMenu();
  });
  
  function system_notification(type, header, message) {
    
    $('#systemNotificationMessage').finish();
    
    $('#systemNotificationMessage')
      .removeClass('negative');
    $('#systemNotificationMessage')
      .removeClass('success');
    
    var icon;
      
    if ( type === "processing" ) {
      icon = 'notched circle loading icon';
    }
    else if ( type === "error" ) {
      icon = '';
      $('#systemNotificationMessage')
        .addClass('negative');
    }
    else if ( type === "confirm" ) {
      icon = 'check icon';
      $('#systemNotificationMessage')
        .addClass('success');
    }
    
    if( icon !== "" ) {
      icon = '<i class="'+ icon +'" id="icon"></i>';
    }
      
    $('#systemNotificationMessage').html(
        icon
      + '<i class="close icon"></i>'
      + '<div class="content">'
        + '<div class="header">'
        + header + '</div>'
        + '<div>'
        + message + '</div>'
      + '</div>'
    );
      
    $('#systemNotificationMessage')
      .slideDown()
      .delay(5000)
      .fadeOut();
  
    $('#systemNotificationMessage .close')
      .on('click', function() {
        $('#systemNotificationMessage')
          .stop().fadeOut();
    });
  }
  
  
</script>
<script type="text/javascript">
      
      var restaurantId = 1;
      var newItemFormCounter = 0;
      var gMarkers = Array;
      var newBranchCounter = 0;
      
      $(document).ready(function() {
        $('#saveItemsButton').hide();
        $('#saveBranchesButton').hide();
        
        $('#updateRestaurantButton').hide();
        $('#cancelRestaurantEditButton').hide();
        
        getRestaurant();
        getBranches();
        getMenu();
        initMap();
      });
      
      function editRestaurant() {
        var restaurantName = $('#restaurantName').html();
        var restaurantPhone = $('#restaurantPhone').html();
        var restaurantEmail = $('#restaurantEmail').html();
        var restaurantDescription = $('#restaurantDescription').html();
        $('#newRestaurantName').val( restaurantName );
        $('#newRestaurantPhone').val( restaurantPhone );
        $('#newRestaurantEmail').val( restaurantEmail );
        $('#newRestaurantDescription').val( restaurantDescription );
        
        $('#newRestaurantNameForm').show();
        $('#newRestaurantDescriptionForm').show();
        $('#restaurantDescription').hide();
        $('#newRestaurantPhoneForm').show();
        $('#restaurantPhone').hide();
        $('#newRestaurantEmailForm').show();
        $('#restaurantEmail').hide();
        
        $('#updateRestaurantButton').show();
        $('#cancelRestaurantEditButton').show();
        $('#editRestaurantButton').hide();
      }
      
      function cancelRestaurantEdit() {
        $('#newRestaurantNameForm').hide();
        $('#newRestaurantDescriptionForm').hide();
        $('#restaurantDescription').show();
        $('#newRestaurantPhoneForm').hide();
        $('#restaurantPhone').show();
        $('#newRestaurantEmailForm').hide();
        $('#restaurantEmail').show();
        
        $('#updateRestaurantButton').hide();
        $('#cancelRestaurantEditButton').hide();
        $('#editRestaurantButton').show();
      }
      
      function updateRestaurant() {
        var restaurantName = $('#newRestaurantName').val();
        var restaurantPhone = $('#newRestaurantPhone').val();
        var restaurantEmail = $('#newRestaurantEmail').val();
        var restaurantDescription = $('#newRestaurantDescription').val();
        
        var data = ({
          operation: 'updateRestaurant',
          restaurantId: restaurantId,
          restaurantName: restaurantName,
          restaurantPhone: restaurantPhone,
          restaurantEmail: restaurantEmail,
          restaurantDescription: restaurantDescription
        });
        
        $.ajax({
          url: requestURL+'/?request=restaurants',
          data: data,
          method: 'post',
          dataType: 'json',
          success: function(response) {
            console.log(response);
            if(response.errors == 0) {
              
              $('#restaurantName').html(restaurantName);
              $('#restaurantDescription').html(restaurantDescription);
              $('#restaurantPhone').html(restaurantPhone);
              $('#restaurantEmail').html(restaurantEmail);
              
              cancelRestaurantEdit();
            }
            else {
              console.log(response);
            }
          },
          error: function(response) {
            console.log(response);
          }
        });
      }
      
      
      function getRestaurant() {
        
        var data = ({
          operation: 'getRestaurant',
          restaurantId: restaurantId
        });
        
        $.ajax({
          
          url: requestURL + '/?request=restaurants',
          data: data,
          method: 'post',
          dataType: 'JSON',
          success: function(response) {
            if (response.errors === 0) {
              $('#restaurantName').html(response.restaurant.name);
              $('#restaurantDescription').html(response.restaurant.description);
              $('#restaurantPhone').html(response.restaurant.phone);
              $('#restaurantEmail').html(response.restaurant.email);
              $('#restaurantCreatedOn').html(response.restaurant.created_on);
              
              if(response.restaurant.approved === 'n') {
                $('#restaurantApprovedStatus').html('Not Approved Yet <a href="#" onclick="approveRestaurant()">'
                                  + 'Approve</a>');
              }
              else {
                $('#restaurantApprovedStatus').html('Approved <a href="#" onclick="disapproveRestaurant()"'
                                 + '>Disapprove</a>');
              }
              
              $('#restaurantApprovedOn').html(response.restaurant.approved_on);
              
            }
            else {
              system_notification('error', 'Cannot load restaurant', 
                'Cannot find the restaurant in the database.')
            }
          },
          error: function(response) {
            console.log(response)
            $('#restaurantsTable').find('tbody').html(
              '<tr><td colspan=\'7\'>No records found</td></tr>'
            );
          }
          
        });
      }
      
      function disapproveRestaurant() {
        var data = ({
          operation: 'disapproveRestaurant',
          restaurantId: restaurantId
        });
        
        $.ajax({
          url: requestURL + '/?request=restaurants',
          data: data,
          method: 'post',
          dataType: 'json',
          success: function (response) {
            if(response.errors === 0) {
              console.log(response);
              $('#restaurantApprovedStatus').html('Not Approved Yet <a href="#" onclick="approveRestaurant()">'
                                  + 'Approve</a>');
              $('#restaurantApprovedOn').html('<i>Refresh page</i>');
            }
            else {
              console.log(response);
            }
          },
          error: function(response) {
            console.log(response);
          }
        });
      }
      
      function approveRestaurant() {
        var data = ({
          operation: 'approveRestaurant',
          restaurantId: restaurantId
        });
        
        $.ajax({
          url: requestURL + '/?request=restaurants',
          data: data,
          method: 'post',
          dataType: 'json',
          success: function (response) {
            if(response.errors === 0) {
              console.log(response);
              $('#restaurantApprovedStatus').html('Approved <a href="#" onclick="disapproveRestaurant()"'
                                 + '>Disapprove</a>');
              $('#restaurantApprovedOn').html('<i>Refresh page</i>');
            }
            else {
              console.log(response);
            }
          },
          error: function(response) {
            console.log(response);
          }
        });
      }
      
      function getBranches() {
        
        var data = ({
          operation: 'getBranches',
          restaurantId: restaurantId
        });
        
        $.ajax({
          
          url: requestURL + '/?request=restaurants',
          data: data,
          method: 'post',
          dataType: 'JSON',
          success: function(response) {
            if (response.errors === 0) {
              
              $('#branchesTable').find('tbody').html('');
              
              
              
              $.each( response.branches, function(key, value) {
                console.log(value);
                
                $('#branchesTable').find('tbody').append(
                  '<tr id="branch-' + value['id'] + '">'
                  + '<td>' + value['id'] + '</td>'
                  + '<td>' + value['name'] + '</td>'
                  + '<td>' + value['bl_lat'] + '</td>'
                  + '<td>' + value['bl_long'] + '</td>'
                  + '<td class="right aligned">'
                  + '<div onclick="editBranch(' + value['id'] + ')" class="link inline button">Edit</div>'
                  + '<div onclick="deleteBranch(' + value['id'] + ')" class="link inline button">Delete</div></td>'
                  + '</tr>'
                  + '<tr id="branch-' + value['id'] + '-form" class="ui form hidden">'
                  + '<td>' + value['id'] + '</td>'
                  + '<td><input class="text" name="branchName" id="branchName" ' 
                  + 'value="' + value['name'] + '"></td>'
                  + '<td><input class="text" name="branchLat" id="branchLat" ' 
                  + 'value="' + value['bl_lat'] + '"></td>'
                  + '<td><input class="text" name="branchLong" id="branchLong" ' 
                  + 'value="' + value['bl_long'] + '"></td>'
                  + '<td class="right aligned">'
                  + '<div onclick="updateBranch(' + value['id'] + ')" class="link inline button">Save</div>'
                  + '<div onclick="cancelEditBranch(' + value['id'] + ')" class="link inline button">Cancel</div></td>'
                  + '</tr>'
                );
                
                var location = { lat: parseFloat(value['bl_lat']), lng: parseFloat(value['bl_long']) } 
                gMarkers[ value['id'] ] = new google.maps.Marker({
                  position: location,
                  label: value['name'],
                  map: map,
                  draggable: true //make it draggable
                });
                
                google.maps.event.addListener(gMarkers[ value['id'] ], 'dragend', function(event){
                  editBranch(value['id']);
                  var currentLocation = gMarkers[ value['id'] ].getPosition();
                  //Add lat and lng values to a field that we can save.
                  $('#branch-' + value['id'] +'-form').find('#branchLat').val( currentLocation.lat() );
                  $('#branch-' + value['id'] +'-form').find('#branchLong').val( currentLocation.lng() );
                });
              });
            }
            else {
              $('#branchesTable').find('tbody').html(
                '<tr><td colspan="4">No records found.</td></tr>'
              );
            }
          },
          error: function(response) {
            console.log(response)
            $('#branchesTable').find('tbody').html(
              '<tr><td colspan=\'4\'>No records found</td></tr>'
            );
          }
          
        });
      }
      
      function addBranch() {
        newBranchCounter++;
        
        var newMarker = Array;
        newMarker[newBranchCounter] = new google.maps.Marker({
          position: map.getCenter(),
          label: 'New branch',
          map: map,
          draggable: true
        });
        
        google.maps.event.addListener(newMarker[ newBranchCounter ], 'dragend', function(event){
          var currentLocation = newMarker[ newBranchCounter ].getPosition();
          //Add lat and lng values to a field that we can save.
          $('#newBranchForm-'+newBranchCounter)
            .find('input[name="branchesLats-'+ newBranchCounter +'"]').val( currentLocation.lat() );
          $('#newBranchForm-'+newBranchCounter)
            .find('input[name="branchesLongs-'+ newBranchCounter +'"]').val( currentLocation.lng() );
        });
        
        $('#branchesTable').find('tbody').append(
          '<tr id="newBranchForm-'+newBranchCounter+'" class="ui form newBranch">'
          + '<td></td>'
          + '<td><div class="field"><input class="" name="branchesNames-' + newBranchCounter
          + '" id="branchesNames['+newBranchCounter+']" value=""></div></td>'
          + '<td><div class="field"><input class="text" name="branchesLats-' + newBranchCounter 
          + '" id="branchesLats['+newBranchCounter+']" value=""></div></td>'
          + '<td><div class="field"><input class="text" name="branchesLongs-' + newBranchCounter 
          + '" id="branchesLongs['+newBranchCounter+']" value=""></div></td>'
          + '<td><div class="link inline button" onclick="removeNewBranchForm('+newBranchCounter+');">'
          + 'Cancel | <span class="save-branch">Save</span></div></td>'
          + '</tr>'
        );


      }
      
      function removeNewBranchForm(id) {
        $('#newBranchForm-'+id).remove();
        
        gMarkers[id].setMap(null);
        
        if( $('.newBranch').length === 0 ) {
          $('#saveBranchesButton').hide();
        }
      }
      
      function saveNewBranches() {
        var errors = 0;
        
        $('input[id^="branchesNames"]').each(function() {
          if ( $.trim( $(this).val() ).length == "" ) {
            $(this).closest('.field').addClass('error');
            errors = 1;
          }
          else {
            $(this).closest('.field').removeClass('error');
          }
        });
        
        $('input[id^="branchesLats"]').each(function() {
          if ( $.trim( $(this).val() ).length == "" ) {
            $(this).closest('.field').addClass('error');
            errors = 1;
          }
          else {
            $(this).closest('.field').removeClass('error');
          }
        });
        
        $('input[id^="branchesLongs"]').each(function() {
          if ( $.trim( $(this).val() ).length == "" ) {
            $(this).closest('.field').addClass('error');
            errors = 1;
          }
          else {
            $(this).closest('.field').removeClass('error');
          }
        });
        
        google.maps.event.trigger(map, 'resize');
        
        if( errors == 0) {
          var branchesNames = $('input[id^="branchesName"').map(function(){return $(this).val();}).get();
          var branchesLats = $('input[id^="branchesLats"').map(function(){return $(this).val();}).get();
          var branchesLongs = $('input[id^="branchesLongs"').map(function(){return $(this).val();}).get();
          
          var data = {
            operation: 'addBranches',
            restaurantId: restaurantId,
            branchesNames: JSON.stringify(branchesNames),
            branchesLats: JSON.stringify(branchesLats),
            branchesLongs: JSON.stringify(branchesLongs)
          };
          
          $.ajax({ 
            url: requestURL+'/?request=restaurants',
            data: data,
            method: 'post',
            dataType: 'json',
            success: function(response) {
              if(response.errors == 0) {
                console.log(response);
                $('#saveBranchesButton').hide();
              }
              else {
                console.log(response)
              }
            },
            error: function(response) {
              console.log(response);
            }
          });
        }
        
      }
      
      function updateBranch(id) {
        var branchName = $('#branch-'+id+'-form').find('#branchName');
        var branchLat = $('#branch-'+id+'-form').find('#branchLat');
        var branchLong = $('#branch-'+id+'-form').find('#branchLong');
        
        var data = ({
          operation: 'updateBranch',
          branchId: id,
          branchName: branchName.val(),
          branchLat: branchLat.val(),
          branchLong: branchLong.val()
        });
        
        $.ajax({
          url: requestURL+'/?request=restaurants',
          data: data,
          method: 'post',
          dataType: 'json',
          success: function(response) {
            if(response.errors == 0) {
              cancelEditBranch(id);
            }
            else {
              console.log(response);
            }
          },
          error: function(response) {
            console.log(response)
          }
        });
      }
      
      function deleteBranch(id) {
        var data = ({
          operation: 'deleteBranch',
          branchId: id
        });
        
        $.ajax({
          url: requestURL+'/?request=restaurants',
          data: data,
          method: 'post',
          dataType: 'json',
          success: function(response) {
            if(response.errors == 0) {
              $('#branch-' + id +'-form').remove();
              $('#branch-' + id).remove();
            }
            else {
              console.log(response);
            }
          },
          error: function(response) {
            console.log(response)
          }
        });
        
      }
      
      function editBranch(id) {
        $('#branch-' + id +'-form').show();
        $('#branch-' + id).hide();
      }
      
      function cancelEditBranch(id) {
        $('#branch-' + id +'-form').hide();
        $('#branch-' + id).show();
      }
      
      function getMenu() {
        
        var data = ({
          operation: 'getMenu',
          restaurantId: restaurantId
        });
        
        $.ajax({
          
          url: requestURL + '/?request=restaurants',
          data: data,
          method: 'post',
          dataType: 'JSON',
          success: function(response) {
            if (response.errors === 0) {
              
              $('#itemsCount').html( '('+ response.menu.length +')' );
              $('#menuTable').find('tbody').html('');
              
              var marker = Array;
              
              $.each( response.menu, function(key, value) {
                
                $('#menuTable').find('tbody').append(
                  '<tr id="item-' + value['id'] + '" class="top aligned">'
                  + '<td>' + value['id'] + '</td>'
                  + '<td id="itemName-' + value['id'] + '-label">' + value['name'] + '</td>'
                  + '<td id="itemDescription-' + value['id'] + '-label">' + value['description'] + '</td>'
                  + '<td id="itemPrice-' + value['id'] + '-label">' + value['price'] + '</td>'
                  + '<td class="right aligned">'
                  + '<div onclick="editItem(' + value['id'] + ')" class="link inline button">Edit</div>'
                  + '<div onclick="deleteItem(' + value['id'] + ')" class="link inline button">Delete</div></td>'
                  + '</tr>'
                  + '<tr id="item-' + value['id'] + '-form" class="ui form hidden top aligned">'
                  + '<td>' + value['id'] + '</td>'
                  + '<td><input class="text" name="itemName-' + value['id'] + '" id="itemName-' + value['id'] + '" ' 
                  + 'value="' + value['name'] + '"></td>'
                  + '<td><textarea class="text" rows="4" name="itemDescription-' + value['id'] + '" id="itemDescription-' + value['id'] + '">' 
                  + value['description'] + '</textarea></td>'
                  + '<td><input class="text" name="itemPrice-' + value['id'] + '" id="itemPrice-' + value['id'] + '" ' 
                  + 'value="' + value['price'] + '"></td>'
                  + '<td class="right aligned">'
                  + '<div onclick="updateItem(' + value['id'] + ')" class="link inline button">Save</div>'
                  + '<div onclick="cancelItemEdit(' + value['id'] + ')" class="link inline button">Cancel</div></td>'
                  + '</tr>'
                );
                
              });
            }
            else {
              $('#menuTable').find('tbody').html(
                '<tr><td colspan="4">No records found.</td></tr>'
              );
            }
          },
          error: function(response) {
            $('#menuTable').find('tbody').html(
              '<tr><td colspan=\'4\'>No records found</td></tr>'
            );
          }
          
        });
      }
      
      function editItem(id) {
        $('#item-' + id).hide();
        $('#item-'+id+'-form').show();
      }
      
      function cancelItemEdit(id) {
        $('#item-' + id).show();
        $('#item-'+id+'-form').hide();
      }
      
      function deleteItem(id) {
        
        var data = ({
          operation: 'deleteItem',
          itemId: id,
        });
        
        $.ajax({
          url: requestURL+'/?request=restaurants',
          data: data,
          dataType: 'json',
          method: 'post',
          success: function(response) {
            console.log(response);
            if(response.errors === 0) {
              console.log(response);
              $('#item-'+id).hide();
            }
            else {
              console.log(response);
            }
            
          },
          error: function(response) {
            console.log(response);
          }
        })
      }
      
      function updateItem(id) {
        
        var itemName = $('#item-'+id+'-form').find('#itemName-'+id);
        var itemDescription = $('#item-'+id+'-form').find('#itemDescription-'+id);
        var itemPrice = $('#item-'+id+'-form').find('#itemPrice-'+id);
        
        var data = ({
          operation: 'updateItem',
          itemId: id,
          itemName: itemName.val(),
          itemDescription: itemDescription.val(),
          itemPrice:itemPrice.val()
        });
        
        $.ajax({
          url: requestURL+'/?request=restaurants',
          data: data,
          dataType: 'json',
          method: 'post',
          success: function(response) {
            console.log(response);
            if(response.errors === 0) {
              console.log(response);
              $('#item-'+id).find('#itemName-'+id+'-label').html(
                itemName.val() );
              $('#item-'+id).find('#itemDescription-'+id+'-label').html(
                itemDescription.val() );
              $('#item-'+id).find('#itemPrice-'+id+'-label').html(
                itemPrice.val() );
              cancelItemEdit(id);
            }
            else {
              console.log(response);
            }
            
          },
          error: function(response) {
            console.log(response);
          }
        })
      }
      
      function addItem() {
        newItemFormCounter += 1;
        
        $('#menuTable').append(
          '<tr id="newItemForm-'+newItemFormCounter+'" class="ui top aligned form newItem">'
          + '<td></td>'
          + '<td>'
            + '<div class="field">'
            + '<input type="text" name="newItemName[]" id="newItemName[]">'
            + '</div>'
          + '</td>'
          + '<td>'
            + '<div class="field">'
            + '<textarea name="newItemDescription[]" id="newItemDescription[]" '
            + 'rows="3"></textarea>'
            + '</div>'
          + '</td>'
          + '<td>'
            + '<div class="field">'
            + '<input type="text" name="newItemPrice[]" id="newItemPrice[]">'
            + '</div>'
          + '</td>'
          + '<td>'
            + '<div class="ui icon button" onclick="removeNewItemForm('+newItemFormCounter+')">'
            + '<i class="cancel icon"></i></div>'
          + '</td>'
          + '</tr>'
        );
        
        $('#saveItemsButton').show();
      }
      
      function saveItems() {
        var errors = 0;
        
        $('input[id="newItemName[]"]').each(function() {
          if ( $.trim( $(this).val() ).length == "" ) {
            $(this).closest('.field').addClass('error');
            errors = 1;
          }
          else {
            $(this).closest('.field').removeClass('error');
          }
        });
        
        $('textarea[id="newItemDescription[]"]').each(function() {
          if ( $.trim( $(this).val() ).length == "" ) {
            $(this).closest('.field').addClass('error');
            errors = 1;
          }
          else {
            $(this).closest('.field').removeClass('error');
          }
        });
        
        $('input[id="newItemPrice[]"]').each(function() {
          if ( $.trim( $(this).val() ).length == "" ) {
            $(this).closest('.field').addClass('error');
            errors = 1;
          }
          else {
            $(this).closest('.field').removeClass('error');
          }
        });
        
        if( errors == 0) {
          var itemsNames = $('input[id="newItemName[]"').map(function(){return $(this).val();}).get();
          var itemsDescriptions = $('textarea[id="newItemDescription[]"').map(function(){return $(this).val();}).get();
          var itemsPrices = $('input[id="newItemPrice[]"').map(function(){return $(this).val();}).get();
          
          var data = {
            operation: 'addItems',
            restaurantId: restaurantId,
            itemsNames: JSON.stringify(itemsNames),
            itemsDescriptions: JSON.stringify(itemsDescriptions),
            itemsPrices: JSON.stringify(itemsPrices)
          };
          
          $.ajax({ 
            url: requestURL+'/?request=restaurants',
            data: data,
            method: 'post',
            dataType: 'json',
            success: function(response) {
              if(response.errors == 0) {
                console.log(itemsNames);
                console.log(itemsDescriptions);
                console.log(itemsPrices);
                console.log(data);
                console.log(response);
                getMenu();
                $('#saveItemsButton').hide();
              }
              else {
                console.log(response)
              }
            },
            error: function(response) {
              console.log(response);
            }
          });
        }
      }
      
      function removeNewItemForm(id) {
        $('#newItemForm-'+id).remove();
        
        if( $('.newItem').length === 0 ) {
          $('#saveItemsButton').hide();
        }
      }
    </script>
</body>
</html>
