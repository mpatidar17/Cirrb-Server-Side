@extends('adminpanel.cirrb')

@section('page-title')
  Dashboard
@endsection

@section('content')

  This is the middle section
  
@endsection