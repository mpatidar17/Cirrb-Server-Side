@extends('adminpanel.cirrb')

@section('page-title')

  {{ $restaurant->name }}

@endsection

@section('content')

<!-- {{ Html::ul( $errors->all() ) }} -->

  <div class="alert alert-error messages"></div>
  {{ Form::open(array('url' => '' ,'id'=> 'edit-restaurant') ) }}
  {{ Form::hidden('restaurant_id',$restaurant->id,array('id'=>'restaurant_id')) }}
<button type="button" class="add-restaurant" id="edit-restaurant-btn"><span class="fa fa-plus"></span> Edit Restaurant</button>
<button type="submit" class="add-restaurant save-btn field-hide"><span class="fa fa-plus"></span> Save</button>
<div class="restaurant-result">
  <div class="col-md-6">
  {{ Form::text('name',$restaurant->name,array('class'=>'form-control field-hide','required' => 'required')) }}
    <div class="col-md-3">
      <p>Description:</p>
    </div>
    <div class="col-md-9">
     <span class="field-show restaurant-description">{{ $restaurant->description }}</span>
     {{ Form::textarea('description',$restaurant->description,array('class'=>'form-control field-hide')) }}
    </div>
  </div>
  <!-- end left hand side col-md-6 -->
  <div class="col-md-6">
    <div class="row">
      <div class="col-md-6">
        <h5>Phone:</h5>
      </div>
    <div class="col-md-6">
      <span class="field-show restaurant-phone">{{ $restaurant->phone }}</span>
      {{ Form::text('phone',$restaurant->phone,array('class'=>'form-control field-hide','required' => 'required','max'=>'10')) }}
    </div>
  </div>
  <div class="row">  
    <div class="col-md-6">
      <h5>Email:</h5>
    </div>
    <div class="col-md-6">
      <span class="field-show restaurant-email">{{ $restaurant->email }}</span>
     {{ Form::text('email',$restaurant->email,array('class'=>'form-control field-hide','required' => 'required')) }}
    </div>
  </div>
  <div class="row">  
    <div class="col-md-6">
      <h5>Created On:</h5>
    </div>
    <div class="col-md-6">
      {{ $restaurant->created_at }}
    </div>
  </div>
  <div class="row">  
    <div class="col-md-6">
      <h5>Approved:</h5>
    </div>
    <div class="col-md-6">
      {{ ($restaurant->approved == 'n') ? 'Unapproved' : 'Approved' }}
    </div>
  </div>
  <div class="row">  
    <div class="col-md-6">
      <h5>Approved On:</h5>
    </div>
    <div class="col-md-6">
      {{ $restaurant->approved_on }}
    </div>
  </div>  
    <!-- end left hand side col-md-6 -->
  </div>
</div>

{{ Form::close() }}










<div class="ui divider container"></div>
    
    <div class="ui grid container">
      <div class="row">
        <div class="column">
          <div class="ui header topMargin">Branshes</div>
          
          <div id="map" class="fullWidthMap">Loading map</div>
          
          <table class="ui basic fixed striped table" id="branchesTable">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Lat</th>
                <th>Long</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td colspan="4">No records found</td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <th colspan="5">
                  <!-- <div class="ui right floated small primary labeled icon button"
                    onclick="addBranch();">
                    <i class="user icon"></i> Add Branch
                  </div>
                  <div class="ui right floated small primary secondaryToPrimary labeled icon button"
                    id="saveBranchesButton" onClick="saveNewBranches();">
                    <i class="check icon"></i> Save
                  </div> -->
                </th>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
    




















<!-- Brach List -->

<div class="clearfix"></div>
  <div class="branch-list-heading">
    <h3>Branches</h3>
  </div>
  <div class="table-box">
    <table class="table table-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Lat</th>
        <th>Long</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      @foreach( $branches as $branch )

        <tr id="form-table-cell-{{$branch->id}}">
          <td>{{ $branch->name }}</td>
          <td>{{ $branch->bl_lat }}</td>
          <td>{{ $branch->bl_long }}</td>
          <td><a href="#"><a href="{{ URL::to('/branches/'.$branch->id.'/edit') }}">Edit</a> | <a href="#">Delete</a></td>
        </tr></a>

      @endforeach

    </tbody>
  </table>
  <button class="add-restaurant" id="add-branch" onclick="addBranch();"><span class="fa fa-plus"></span> Add Branch</button>

<!-- End Branch List -->

<!-- Menu List -->
  
<div class="clearfix"></div>
  <div class="Menu-list-heading">
    <h3>Menus</h3>
  </div>
  <div class="table-box">
    <table class="table table-bordered" id="menus-table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Description</th>
        <th>Price</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      @foreach( $menus as $menu )

        <tr id="form-table-cell-{{$menu->id}}">
          <td>{{ $menu->name }}</td>
          <td>{{ $menu->description }}</td>
          <td>{{ $menu->price }}</td>
          <td><a id="edit-menu">Edit</a> | <a href="#">Delete</a></td>
        </tr></a>

      @endforeach

    </tbody>
  </table>
  <button class="add-restaurant" id="add-menu"><span class="fa fa-plus"></span> Add Menu</button>

<!-- End Menu List -->

@endsection