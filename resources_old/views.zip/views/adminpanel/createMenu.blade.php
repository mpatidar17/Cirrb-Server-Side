@extends('adminpanel.cirrb')

@section('content')

    {{ Form::open(array( 'url' => 'menus' )) }}  

             <p>New Menu</p>  
       
                {{ Form::label('name','Name:') }}
                {{ Form::text('name',Input::old('name'),array('class'=>'form-control')) }}

              {{ Form::label('description','Description:') }}
              {{ Form::text('description',Input::old('description'),array('class'=>'form-control', 'id' => 'pwd')) }}

              {{ Form::label('price','Price:') }}
              {{ Form::text('price',Input::old('price'),array('class'=>'form-control', 'id' => 'pwd')) }}

          {{ Form::hidden( 'restaurant_id',$restaurant_id ) }}

            {{ Form::submit('Create Menu') }}

    {{ Form::close() }}

@endsection